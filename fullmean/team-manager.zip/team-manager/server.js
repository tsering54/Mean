const express = require('express');
const path = require('path');
const app = express();
const PORT  = 8000;
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'dist')));

require('./server/config/database');
require('./server/config/routes')(app);


app.listen(PORT, ()=>{
  console.log('listening on port' + PORT);
});