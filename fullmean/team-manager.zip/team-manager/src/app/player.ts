export class Player{
    constructor(
        public id: number = Math.floor(Math.random() * 9999) + 1,
        public name: String='',
        public position: String='',
        public status: String='',
    ){}

}