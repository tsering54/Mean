import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component'
import { AddComponent } from './add/add.component'
import { ListComponent } from './list/list.component'
import { PlayersComponent } from './players/players.component'
import { GamesComponent } from './games/games.component'


const routes: Routes = [
    { path: '', pathMatch: 'full', redirectTo: '/players/list' },
    { path: 'players', pathMatch: 'prefix', component: PlayersComponent ,
      children: [
            {path: 'list', component: ListComponent},
            {path: 'addplayer', component: AddComponent}
      ]
    },
    {path: 'status/game', component: GamesComponent,
      children: [
        {path: '', redirectTo: '1', pathMatch: 'full'},
        {path: '1', component: GamesComponent},
        {path: '2', component: GamesComponent},
        {path: '3', component: GamesComponent}
      ]
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutes { }