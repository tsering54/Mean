import { Component } from '@angular/core';
import { Player } from './player';
import { PlayerService } from './player.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  players = [
    new Player(1, 'Alex Morgan', 'Forward', 'Playing'),
    new Player(2, 'Carlie Lloyd', 'Midfielder', 'Not Playing'),
    new Player(3, 'Lionel Messi', 'Forward', 'Undecided'),
    new Player(4, 'Neymar', 'Forward'),
  ];

  constructor(private playerService: PlayerService) {
    this.playerService.updatePlayers(this.players);
    this.playerService.playersObservable.subscribe( (players) => {
      this.players = players;
    });
  }
}
