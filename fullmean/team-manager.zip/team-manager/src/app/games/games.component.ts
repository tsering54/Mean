import { Component, OnInit } from '@angular/core';
import { PlayerService } from './../player.service';
import { Player } from './../player';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css']
})
export class GamesComponent implements OnInit {
  players: Array<Player>;
  player: Player;
  games:[{number:1},{number:2},{number:3}]

  game: object = {
    number: 1,
  }

  constructor(private route: ActivatedRoute,
    private playerService: PlayerService,
    private router: Router) { 
      this.playerService.playersObservable
      .subscribe( (players) => {
        this.players = players;
  
    });
  }

  ngOnInit() {
    this.playerService.playersObservable.subscribe( (players) => {
      this.players = players;
    });
  }

  selectedGame(num){
    this.game = {
      number: num,
    }
  }

  playing(player){
    player.status='Playing';
    console.log(player);
    
  }
  notPlaying(player){
    player.status='Not Playing';
    console.log(player);
    
  }
  undecided(player){
    player.status='Undecided';
    console.log(player);
  }

  

}
