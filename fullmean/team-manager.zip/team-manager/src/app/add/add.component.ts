import { PlayerService } from './../player.service';
import { Player } from './../player';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  newPlayer: Player = new Player();
  players: Array<Player>;

  constructor(
    private playerService: PlayerService,
    private router: Router
  ) {
    this.playerService.playersObservable.subscribe( (players) => {
      this.players = players;
    })
  }

  ngOnInit() {
    this.newPlayer = new Player();
  }

  create() {
    this.players.push(this.newPlayer);
    this.playerService.updatePlayers(this.players);
    this.newPlayer = new Player();
    this.router.navigate(['']);
  }

}
