import { Player } from './player';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable()
export class PlayerService {
  playersObservable = new BehaviorSubject(null);

  constructor() { }

  updatePlayers(players: Array<Player>) {
    this.playersObservable.next(players);
  }

}
