import { Component, OnInit } from '@angular/core';
import { PlayerService } from './../player.service';
import { Player } from './../player';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  players: Array<Player> = [];

  constructor(private playerService: PlayerService) { }

  ngOnInit() {
    this.playerService.playersObservable.subscribe( (players) => {
      this.players = players;
    });
  }

  deletePlayer(player) {
    const idx = this.players.indexOf(player);
    this.players.splice(idx, 1);
    this.playerService.updatePlayers(this.players);
  }

}
