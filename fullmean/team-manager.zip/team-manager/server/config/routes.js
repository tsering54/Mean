const playerController = require('../controllers/players');
const path = require('path');

module.exports = function(app){
    app.get('/api/players', playerController.index);
    app.get('/api/players/add', playerController.create);
    app.post('/api/players', playerController.create);
    app.delete('/api/games', playerController.destroy);

    app.all('*', function(req, res){
        res.sendFile(path.resolve('dist', 'index.html'))
    });
}
