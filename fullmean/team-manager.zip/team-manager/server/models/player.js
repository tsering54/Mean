const mongoose = require('mongoose');
const { Schema } = mongoose;

const PlayerSchema = new Schema({
    name: {
        type: String,
        required: [true, 'name is required'],
        trim: true,
        minlength: [2, 'name should be at least 2 characters']
    },
    position: {
        type: String
    }
}, {timestamps: true})

module.exports = mongoose.model('Player', PlayerSchema);