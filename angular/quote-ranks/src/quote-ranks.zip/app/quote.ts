export class Quote{
    content:string='';
    author:string='';
    rating: number=0;
   
}