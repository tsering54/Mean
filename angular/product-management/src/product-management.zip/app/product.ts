export class Product{
    id: number=Math.random()*999+1;
    title: string='';
    price: number=0;
    imgUrl: string=null;
}